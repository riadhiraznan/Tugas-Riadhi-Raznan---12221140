package com.example.klinik_mobile_apps

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
